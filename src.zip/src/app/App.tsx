// import AppRoutes from '@/routes'

import Details from "@/features/details/Details";

// function App() {
//   return <AppRoutes />
// }

// export default App

function App() {
  return <Details/>
}

export default App